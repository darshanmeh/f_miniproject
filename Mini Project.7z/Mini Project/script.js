$(document).ready(function () {



    // function getStateWeather() {
    //     $.ajax({
    //         type: 'GET',
    //         dataType: 'json',
    //         url: 'http://api.weatherapi.com/v1/current.json?key=f0926ce707b34cc297785811201910&q=mumbai',
    //         success: function (res) {
    //             console.log(res);
    //             var data_block = `
    //             <div class="container" style="background-color: pink">
    //                 <div class="weather_data">
    //                     <p>City : ${res.location.name}</p>
    //                     <p>Temperatture is : ${res.current.temp_c}</p>
    //                     <p>condition: ${res.current.condition.text}, <img src="${res.current.condition.icon}" alt=""> </p>
    //                  </div>
    //             </div> 
                
    //             `
    //             $('#city-car-one').append(data_block);

    //         }
    //     })


    // }


    function getWeather(city, myBlock) {
        $.ajax({
            type: 'GET',
            dataType: 'json',
            url: 'http://api.weatherapi.com/v1/current.json?key=f0926ce707b34cc297785811201910&q=' + city,
            success: function (res) {
                console.log(res);
                var data_block = `
                <div class="container " style="background-color: pink">
                    <div class="weather_data text-center">
                        <p><h3>${res.location.name}</h3></p>
                        <p><small>(${res.location.region},${res.location.country})</small></p>
                        <p>Temperature : ${res.current.temp_c}<sup>o</sup>C</p>
                        <p><small>Humidity : ${res.current.humidity}%</small></p>
                        <p>Condition: ${res.current.condition.text} <img src="${res.current.condition.icon}" alt=""> </p>
                     </div>
                </div> 
                
                `
                $(myBlock).append(data_block);

            }
        })
    }

    $('#submit_city').click(function(e){
        e.preventDefault();
        var city_name = $('#search_city').val();
        $('.data_container').empty();
        getWeather(city_name, '.data_container');
    })
    // getWeather('mumbai');
    // getWeather('pune');
    // getWeather('nagpur');
    // getWeather('indore');
    // //getWeather('berlin');
    getWeather('pune', '#city-car-one');
    getWeather('mumbai', '#city-car-two');
    getWeather('aurangabad', '#city-car-three');
    getWeather('nagpur', '#city-car-four');


    getWeather('new delhi', '#ind-one');
    getWeather('chennai', '#ind-two');
    getWeather('bangalore', '#ind-three');


    getWeather('new york', '#uni-one');
    getWeather('london', '#uni-two');
    getWeather('tokyo', '#uni-three');

    function getGeoWeather(late, lange,myBlock) {
        $.ajax({
            type: 'GET',
            dataType: 'json',
            url: 'http://api.weatherapi.com/v1/current.json?key=f0926ce707b34cc297785811201910&q='+late+','+lange,
            success: function (res) {
                console.log(res);
                var data_block = `
                <div class="container " style="background-color: pink">
                    <div class="weather_data text-center">
                        <p><h3>${res.location.name}</h3></p>
                        <p><small>(${res.location.region},${res.location.country})</small></p>
                        <p>Temperature : ${res.current.temp_c}<sup>o</sup>C</p>
                        <p><small>Humidity : ${res.current.humidity}%</small></p>
                        <p>Condition: ${res.current.condition.text} <img src="${res.current.condition.icon}" alt=""> </p>
                     </div>
                </div> 
                
                `
                $(myBlock).append(data_block);

            }
        })
    }



    $("#find_btn").click(function (e) { //user clicks button
        if ("geolocation" in navigator){ //check geolocation available 
            //try to get user current location using getCurrentPosition() method
            navigator.geolocation.getCurrentPosition(function(position){ 
                    // $("#result").html("Found your location <br />Lat : "+position.coords.latitude+" </br>Lang :"+ position.coords.longitude);
                    e.preventDefault();
                    $('#result').empty();
                    getGeoWeather(position.coords.latitude,position.coords.longitude,'#result');

                });
        }else{
            console.log("Browser doesn't support geolocation!");
        }
    });
})









function validateForm() {
    var name =  document.getElementById('name').value;
    if (name == "") {
        document.querySelector('.status').innerHTML = "Name cannot be empty";
        return false;
    }
    var email =  document.getElementById('email').value;
    if (email == "") {
        document.querySelector('.status').innerHTML = "Email cannot be empty";
        return false;
    } else {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(!re.test(email)){
            document.querySelector('.status').innerHTML = "Email format invalid";
            return false;
        }
    }
    var subject =  document.getElementById('subject').value;
    if (subject == "") {
        document.querySelector('.status').innerHTML = "Subject cannot be empty";
        return false;
    }
    var message =  document.getElementById('message').value;
    if (message == "") {
        document.querySelector('.status').innerHTML = "Message cannot be empty";
        return false;
    }
    document.querySelector('.status').innerHTML = "Sending...";
  }















// style="background-color: pink"

















// $(document).ready(function () {



//     function getWeather(c) {
//         $.ajax({
//             type: 'GET',
//             dataType: 'json',
//             url: 'http://api.weatherapi.com/v1/current.json?key=f0926ce707b34cc297785811201910&q=' + c,
//             success: function (res) {
//                 console.log(res);
//                 var data_block = `
//                 <div class="container" style="background-color: pink">
//                     <div class="weather_data">
//                         <p>City : ${res.location.name}</p>
//                         <p>Temperatture is : ${res.current.temp_c}</p>
//                         <p>condition: ${res.current.condition.text}, <img src="${res.current.condition.icon}" alt=""> </p>
//                      </div>
//                 </div> 
                
//                 `
//                 $('.data_container').append(data_block);

//             }
//         })
//     }

//     $('#submit_city').click(function(e){
//         e.preventDefault();
//         var city_name = $('#search_city').val();
//         getWeather(city_name);
//     })

//     getWeather('pune');
//     getWeather('berlin');


// })



























// function addWeather(d){

// }


// function weatherBalloon(cityName) {

//     fetch('http://api.weatherapi.com/v1/current.json?key=f0926ce707b34cc297785811201910&q=' + cityName)
//         .then(function (resp) { return resp.json() }) // Convert data to json
//         .then(function (data) {
//              addWeather(data);

//         })
//         .catch(function () {
//             // catch any errors
//         });
// }





// window.onload = function () {
//     weatherBalloon('New York');
// }







// $(document).ready(function(){
//     $('button').click(function(){
//         $.ajax({
//             type: 'GET',
//             dataType: 'json',
//             url: 'http://api.weatherapi.com/v1/current.json?key=f0926ce707b34cc297785811201910&q=London',
//             success: function(res){
//                 console.log('successfully get data from json-server')

//                 // console.log(res.current.temp_c);

//                 let users = []              
                // $.each(res, function(i, v){
                //     users += 
                //     `
                //     <div class="user">
                //         <p>Id: ${v.id}</p>
                //         <p>Username: ${v.username}</p>
                //         <p>Password: ${v.password}</p>
                //     </div>
                //     `
                // })
                // $('.container').append(users)       
//                 // $.each(res, function(i, v){
//                 //     users += 
//                 //     `
//                 //     <div class="user">
//                 //         <p>Id: ${v.id}</p>
//                 //         <p>Username: ${v.username}</p>
//                 //         <p>Password: ${v.password}</p>
//                 //     </div>
//                 //     `
//                 // })
//                 // $('.container').append(users)                
//                 // $('img').hide()
//             }
//         })
//     })
// })